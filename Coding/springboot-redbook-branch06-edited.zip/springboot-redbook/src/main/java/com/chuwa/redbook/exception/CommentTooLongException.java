package com.chuwa.redbook.exception;

public class CommentTooLongException extends RuntimeException {
    public CommentTooLongException(String message) {

        super(message);
    }
}
