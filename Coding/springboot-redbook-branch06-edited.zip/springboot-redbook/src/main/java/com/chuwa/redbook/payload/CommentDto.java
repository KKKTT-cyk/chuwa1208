package com.chuwa.redbook.payload;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
/**
 * @author b1go
 * @date 6/23/22 11:10 PM
 */
public class CommentDto {

    private long id;
    private String name;

    @NotEmpty(message = "Email should not be null or empty")
    @Pattern(
            regexp = "^[A-Za-z0-9]+@[A-Za-z0-9]+\\.[A-Za-z]+$",
            message = "Email must follow the format: lettersOrDigits@lettersOrDigits.domain"
    )
    private String email;
    private String body;

    public CommentDto() {
    }

    public CommentDto(String name, String email, String body) {
        this.name = name;
        this.email = email;
        this.body = body;
    }

    public CommentDto(long id, String name, String email, String body) {
        this(name, email, body);
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "CommentDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", body='" + body + '\'' +
                '}';
    }
}
